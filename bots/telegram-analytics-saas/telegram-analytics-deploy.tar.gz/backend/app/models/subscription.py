"""
Модель подписки пользователя
"""
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True)
    plan_type = Column(String, nullable=False, default="trial")  # trial, starter, professional, enterprise
    start_date = Column(DateTime, default=datetime.utcnow)
    end_date = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    
    # Лимиты тарифа
    max_bots = Column(Integer, default=1)
    max_channels = Column(Integer, default=2)
    has_sheets_export = Column(Boolean, default=True)
    has_api_access = Column(Boolean, default=False)
    history_days = Column(Integer, default=30)
    
    # Stripe данные
    stripe_customer_id = Column(String, nullable=True)
    stripe_subscription_id = Column(String, nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="subscription")

    def __repr__(self):
        return f"<Subscription(id={self.id}, user_id={self.user_id}, plan={self.plan_type})>"
