"""
Модель активности участника (на основе MemberActivity из telegram_member_tracker/models.py)
"""
from sqlalchemy import Column, Integer, String, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class Activity(Base):
    __tablename__ = "activities"

    id = Column(Integer, primary_key=True, index=True)
    member_id = Column(Integer, ForeignKey("members.id", ondelete="CASCADE"), nullable=False)
    channel_id = Column(Integer, ForeignKey("channels.id", ondelete="CASCADE"), nullable=False)
    activity_type = Column(String, nullable=False, index=True)  # joined, left, promoted, demoted, status_changed
    old_status = Column(String, nullable=True)
    new_status = Column(String, nullable=True)
    timestamp = Column(DateTime, default=datetime.utcnow, index=True)
    details = Column(Text, nullable=True)
    
    # Relationships
    member = relationship("Member", back_populates="activities")
    channel = relationship("Channel", back_populates="activities")

    def __repr__(self):
        return f"<Activity(id={self.id}, type={self.activity_type}, member_id={self.member_id})>"
