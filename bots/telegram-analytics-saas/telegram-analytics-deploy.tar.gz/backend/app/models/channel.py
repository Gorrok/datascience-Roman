"""
Модель Telegram канала
"""
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, BigInteger
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class Channel(Base):
    __tablename__ = "channels"

    id = Column(Integer, primary_key=True, index=True)
    bot_id = Column(Integer, ForeignKey("bots.id", ondelete="CASCADE"), nullable=False)
    telegram_channel_id = Column(BigInteger, nullable=False, unique=True, index=True)
    channel_username = Column(String, nullable=True, index=True)
    channel_title = Column(String, nullable=True)
    added_at = Column(DateTime, default=datetime.utcnow)
    is_monitoring = Column(Boolean, default=True)
    
    # Relationships
    bot = relationship("Bot", back_populates="channels")
    invite_links = relationship("InviteLink", back_populates="channel", cascade="all, delete-orphan")
    members = relationship("Member", back_populates="channel", cascade="all, delete-orphan")
    activities = relationship("Activity", back_populates="channel", cascade="all, delete-orphan")
    google_sheets_config = relationship("GoogleSheetsConfig", back_populates="channel", uselist=False)

    def __repr__(self):
        return f"<Channel(id={self.id}, username={self.channel_username})>"
