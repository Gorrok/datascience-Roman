"""
Модель бота пользователя
"""
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class Bot(Base):
    __tablename__ = "bots"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    bot_token_encrypted = Column(Text, nullable=False)  # Зашифрованный токен
    bot_username = Column(String, nullable=False)
    bot_name = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)
    status = Column(String, default="stopped")  # stopped, running, error
    last_error = Column(Text, nullable=True)
    
    # Relationships
    user = relationship("User", back_populates="bots")
    channels = relationship("Channel", back_populates="bot", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Bot(id={self.id}, username={self.bot_username}, status={self.status})>"
