"""
Модель участника канала (на основе ChannelMember из telegram_member_tracker/models.py)
"""
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey, BigInteger
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class Member(Base):
    __tablename__ = "members"

    id = Column(Integer, primary_key=True, index=True)
    channel_id = Column(Integer, ForeignKey("channels.id", ondelete="CASCADE"), nullable=False)
    invite_link_id = Column(Integer, ForeignKey("invite_links.id", ondelete="SET NULL"), nullable=True)
    telegram_user_id = Column(BigInteger, nullable=False, index=True)
    username = Column(String, nullable=True)
    first_name = Column(String, nullable=True)
    last_name = Column(String, nullable=True)
    joined_at = Column(DateTime, default=datetime.utcnow)
    left_at = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    status = Column(String, default="member")  # member, administrator, creator, left, kicked, banned
    notes = Column(String, nullable=True)
    
    # Relationships
    channel = relationship("Channel", back_populates="members")
    invite_link = relationship("InviteLink", back_populates="members")
    activities = relationship("Activity", back_populates="member", cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Member(id={self.id}, user_id={self.telegram_user_id}, channel_id={self.channel_id})>"
