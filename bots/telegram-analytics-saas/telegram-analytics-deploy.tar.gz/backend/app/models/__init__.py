"""
Импорт всех моделей для удобства
"""
from app.models.user import User
from app.models.bot import Bot
from app.models.channel import Channel
from app.models.invite_link import InviteLink
from app.models.member import Member
from app.models.activity import Activity
from app.models.subscription import Subscription
from app.models.google_sheets_config import GoogleSheetsConfig

__all__ = [
    "User",
    "Bot",
    "Channel",
    "InviteLink",
    "Member",
    "Activity",
    "Subscription",
    "GoogleSheetsConfig",
]
