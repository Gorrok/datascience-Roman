"""
Модель инвайт-ссылки
"""
from sqlalchemy import Column, Integer, String, DateTime, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime

from app.core.database import Base


class InviteLink(Base):
    __tablename__ = "invite_links"

    id = Column(Integer, primary_key=True, index=True)
    channel_id = Column(Integer, ForeignKey("channels.id", ondelete="CASCADE"), nullable=False)
    link_name = Column(String, nullable=False)
    invite_url = Column(String, nullable=False, unique=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    total_joins = Column(Integer, default=0)
    is_active = Column(Boolean, default=True)
    
    # Relationships
    channel = relationship("Channel", back_populates="invite_links")
    members = relationship("Member", back_populates="invite_link")

    def __repr__(self):
        return f"<InviteLink(id={self.id}, name={self.link_name}, joins={self.total_joins})>"
