"""
Модель конфигурации Google Sheets
"""
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, Text
from sqlalchemy.orm import relationship

from app.core.database import Base


class GoogleSheetsConfig(Base):
    __tablename__ = "google_sheets_configs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    channel_id = Column(Integer, ForeignKey("channels.id", ondelete="CASCADE"), nullable=False, unique=True)
    spreadsheet_id = Column(String, nullable=False)
    credentials_json_encrypted = Column(Text, nullable=False)  # Зашифрованный JSON credentials
    auto_sync = Column(Boolean, default=False)
    sync_interval_minutes = Column(Integer, default=60)
    
    # Relationships
    user = relationship("User", back_populates="google_sheets_configs")
    channel = relationship("Channel", back_populates="google_sheets_config")

    def __repr__(self):
        return f"<GoogleSheetsConfig(id={self.id}, channel_id={self.channel_id})>"
