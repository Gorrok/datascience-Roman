import axios from 'axios';

const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

export const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Интерсептор для добавления токена
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Интерсептор для обработки ошибок и refresh токена
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      try {
        const refreshToken = localStorage.getItem('refresh_token');
        const response = await axios.post(`${API_URL}/auth/refresh`, {
          refresh_token: refreshToken,
        });

        const { access_token, refresh_token } = response.data;
        localStorage.setItem('access_token', access_token);
        localStorage.setItem('refresh_token', refresh_token);

        originalRequest.headers.Authorization = `Bearer ${access_token}`;
        return api(originalRequest);
      } catch (refreshError) {
        localStorage.removeItem('access_token');
        localStorage.removeItem('refresh_token');
        window.location.href = '/auth/login';
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// API функции для аутентификации
export const authApi = {
  register: (data: { email: string; password: string; full_name?: string }) =>
    api.post('/auth/register', data),
  
  login: (data: { username: string; password: string }) =>
    api.post('/auth/login', new URLSearchParams(data), {
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    }),
  
  logout: () => api.post('/auth/logout'),
  
  getMe: () => api.get('/auth/me'),
};

// API функции для ботов
export const botsApi = {
  getAll: () => api.get('/bots'),
  
  getOne: (id: number) => api.get(`/bots/${id}`),
  
  create: (data: { bot_token: string }) => api.post('/bots', data),
  
  start: (id: number) => api.post(`/bots/${id}/start`),
  
  stop: (id: number) => api.post(`/bots/${id}/stop`),
  
  delete: (id: number) => api.delete(`/bots/${id}`),
};

// API функции для каналов
export const channelsApi = {
  getAll: (botId: number) => api.get('/channels', { params: { bot_id: botId } }),
  
  getOne: (id: number) => api.get(`/channels/${id}`),
  
  create: (botId: number, data: {
    telegram_channel_id: number;
    channel_username?: string;
    channel_title?: string;
  }) => api.post('/channels', data, { params: { bot_id: botId } }),
  
  update: (id: number, data: { is_monitoring?: boolean; channel_title?: string }) =>
    api.patch(`/channels/${id}`, data),
  
  delete: (id: number) => api.delete(`/channels/${id}`),
};

// API функции для аналитики
export const analyticsApi = {
  getStats: (channelId: number) =>
    api.get(`/analytics/channels/${channelId}/stats`),
  
  getGrowthTrend: (channelId: number, days: number = 30) =>
    api.get(`/analytics/channels/${channelId}/growth-trend`, { params: { days } }),
  
  getInviteLinksStats: (channelId: number) =>
    api.get(`/analytics/channels/${channelId}/invite-links`),
  
  getRetention: (channelId: number, days: number = 30) =>
    api.get(`/analytics/channels/${channelId}/retention`, { params: { days } }),
  
  getActivity: (channelId: number, limit: number = 50) =>
    api.get(`/analytics/channels/${channelId}/activity`, { params: { limit } }),
};
